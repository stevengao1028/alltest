# coding=utf-8
import sys
from flask import Flask,render_template, jsonify,request
import socket,struct
import fcntl
import json
from system_info import *


app = Flask(__name__)



@app.route('/disk')
def disk():
   return render_template('disk.html')


@app.route('/disk_restore',methods=['GET','POST'])
def disk_restore():
    if request.method == 'POST':
        ip = request.form.get("ip")
        disk = request.form.get("name")
        if ip and disk:
            result = disk_init(ip,disk)
        else:
            result = {'status': "1", 'info': "disk or ip can`t be null"}
    return jsonify(result)

@app.route('/diskinfo/')
def diskinfo():
    query_result = disk_info(ip="127.0.0.1")
    result = {'data':query_result}
    return jsonify(result)

@app.route('/zfs')
def zfs_detail():
   return render_template('zfs.html')

@app.route('/zfscreate')
def zfs_create():
   return render_template('zfscreate.html')

@app.route('/zfsinfo/')
def zfsinfo():
    query_result = zpool_info(ip="127.0.0.1")
    result = {'data':query_result}
    return jsonify(result)


@app.route('/md')
def md_detail():
   return render_template('md.html')

@app.route('/mdinfo/')
def mdinfo():
    query_result = md_info(ip="127.0.0.1")
    result = {'data':query_result}
    return jsonify(result)

@app.route('/lvm')
def lvm_detail():
   return render_template('lvm.html')

@app.route('/lvminfo/')
def lvminfo():
    query_result = lvm_info(ip="127.0.0.1")
    result = {'data':query_result}
    return jsonify(result)



@app.route('/')
def index():
   return render_template('index.html')
@app.route('/flot')
def flot():
   return render_template('flot.html')

@app.route('/login')
def login():
   return render_template('login.html')

@app.route('/blank')
def blank():
   return render_template('blank.html')


@app.route('/panels-wells')
def panels():
   return render_template('pannels-wells.html')
@app.route('/morris')
def morris():
   return render_template('morris.html')

@app.route('/tables')
def tables():
   return render_template('tables.html')
@app.route('/forms')
def forms():
   return render_template('forms.html')
@app.route('/bottons')
def bottons():
   return render_template('bottons.html')
@app.route('/Typography')
def Typography():
   return render_template('Typography.html')

def get_ip_address(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,  # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])

if __name__ == "__main__":
     try:
        eth=sys.argv[1]
     except IndexError,e:
        print "Warning: Please input port of eth"
        sys.exit(1)
     Runip= get_ip_address(eth)
     app.run(
	host=Runip,
	port=5000,
	)