/*
Description:	运行代码演示[VIP][ZBLOG-PHP插件]
Website:		https://app.zblogcn.com/?id=816
Author:			尔今 erx@qq.com
Author URL:		http://www.yiwuku.com/
*/

!window.jQuery && alert("很遗憾，运行代码演示插件无法启用！原因是当前主题jQuery加载异常，可能缺失或不规范导致，建议联系主题作者修复或换用其它主题。");
var preStyle, cdMode = 0;
if(codeAll==1){
	preStyle="pre[class*='brush:'],pre[class*='prism']";
}else{
	preStyle="pre[class*='html'],pre[class*='markup'],pre[class*='js'],pre[class*='javascript'],pre[class*='css']";
}
//Loading
$(preStyle).each(function(){
	yid = "pre_" + preNum;
	precode = $(this).html();
	xyattr = $(this).attr("class");
	runbtn = "<input type='button' value='运行代码' onclick=\"runCode('" + yid + "')\" class='cdmbtn runbtn'>";
	editbtn = "<input type='button' value='编辑模式' class='cdmbtn editbtn'>";
	bestbtn = "<input type='button' value='最佳高度' class='cdmbtn bestbtn'>";
	copybtn = "<input type='button' value='复制' class='cdmbtn copybtn'>";
	foldbtn = "<input type='button' value='折叠' class='cdmbtn foldbtn'>";
	ywkcdmtip = "<span class='ywkcdmtip'></span>";
	$(this).after("<div class=\"ywkcdm\" data=\""+xyattr+"\">"+runbtn+editbtn+bestbtn+copybtn+foldbtn+ywkcdmtip+"</div>").attr("id", yid);
	$(this).after("<textarea id='t"+yid+"' class='ywkcdm_code'>"+precode+"</textarea>");
	preNum++;
});
$(".ywkcdm:not([data*='html'],[data*='markup'],[data*='js'],[data*='javascript'],[data*='css'])").find(".runbtn").attr({disabled:"disabled",title:"此种代码无法直接运行演示"}).addClass("disabled");
//Edit-Run
$("textarea[id*='tpre']").blur(function(){
	$(this).text($(this).val());
});
//Run
function runCode(con) {
	var c = window.open("", "", "");
	c.document.open("text/html", "replace");
	c.opener = null;
	c.document.write($("#" + con).next("textarea").html()
		.replace(/&lt;/g, "<")
		.replace(/&gt;/g, ">")
		.replace(/&nbsp;/g, " ")
		.replace(/&quot;/g, '"')
		.replace(/&amp;/g, "&")
	);
	c.document.close();
}
document.writeln('<script src="'+zbPath+'zb_users/plugin/Codemo_vip/js/clipboard.min.js" type="text/javascript"><\/script>');
$(function(){
	//Edit
	if(codeText==1){
		$(".editbtn").hide();
		$(".bestbtn").show();
		$("pre[id^='pre_']").addClass("ywkhide");
		$("textarea[id^='tpre_']").addClass("ywkshow").height(textHeight);
		$(".ywkcdm .bestbtn").each(function(){
			var ptline=$(this).parent().prev("textarea").text().split("\n").length;
			$(this).click(function(){
				var ptfocus=$(this).parent().prev("textarea").offset().top;
				$(this).parent().prev("textarea").animate({height:ptline*18+"px"});
				$("html,body").animate({ scrollTop : ptfocus-180+'px' });
			});
		});
	}else{
		$(".bestbtn").hide();
		$(".ywkcdm .editbtn").each(function(){
			var ptline=$(this).parent().prev().prev().children("code").height();
			$(this).click(function(){
				$(this).parent().prev().prev().toggleClass("ywkhide");
				$(this).parent().prev().toggleClass("ywkshow").css({height:ptline+"px"});
				if("编辑模式" == $(this)[0].value){
					$(this)[0].value = "恢复默认";
				}else{
					$(this)[0].value = "编辑模式";
				}
			});
		});
	}
	if(copyRights == 1){
		var thispageurl=window.location.href;
		$("pre[id^='pre_']").each(function(){
			$(this).html($(this).html()+'<span style="position:absolute;left:-9999px;">\r\n\r\n'+copyTips+thispageurl+'</span>');
		});
		$(".copybtn").click(function(){
			if($(this).parent().prev("textarea").is(":visible")){
				cdMode = 1;
			}else{
				cdMode = 0;
			}
			if(cdMode == 1){
				$(this).parent().prev("textarea").val($(this).parent().prev("textarea").val()+'\r\n\r\n'+copyTips+thispageurl);
			}
		});
	}
	//Fold
	$(".ywkcdm .foldbtn").each(function(){
		$(this).click(function(){
			$(this).parent().prev("textarea").toggleClass("cdminbar");
			$(this).parent().prev("textarea").prev("pre[id^='pre_']").toggleClass("cdminbar");
			if("折叠" == $(this)[0].value){
				$(this)[0].value = "展开";
				$(this).prev(".copybtn").hide();
				$(this).prev(".copybtn").prev(".bestbtn").hide();
				$(this).prev(".copybtn").prev(".bestbtn").prev(".editbtn").hide();
				$(this).prev(".copybtn").prev(".bestbtn").prev(".editbtn").prev(".runbtn").hide();
			}else{
				$(this)[0].value = "折叠";
				$(this).prev(".copybtn").show();
				if(codeText==1){
					$(this).prev(".copybtn").prev(".bestbtn").show();
				}else{
					$(this).prev(".copybtn").prev(".bestbtn").prev(".editbtn").show();
				}
				$(this).prev(".copybtn").prev(".bestbtn").prev(".editbtn").prev(".runbtn").show();
			}
		});
	});
	if(codeFold==1){
		$(".ywkcdm .foldbtn").each(function(){
			$(this).parent().prev("textarea").addClass("cdminbar");
			$(this).parent().prev("textarea").prev("pre[id^='pre_']").addClass("cdminbar");
			$(this).val("展开");
			$(this).prev(".copybtn").hide();
			$(this).prev(".copybtn").prev(".bestbtn").hide();
			$(this).prev(".copybtn").prev(".bestbtn").prev(".editbtn").hide();
			$(this).prev(".copybtn").prev(".bestbtn").prev(".editbtn").prev(".runbtn").hide();
		});
	}
	//Copy
	var clip = new Clipboard(".copybtn", {
        target: function(trigger) {
        	if(cdMode == 1){
        		return trigger.parentNode.previousSibling;
        	}else{
	            return trigger.parentNode.previousSibling.previousSibling;
	        }
        }
    });
	clip.on('error', function (e) {
		debugstr("浏览器不支持，复制失败！");
	});
	clip.on('success', function (e) {
		debugstr("复制成功！");
		e.clearSelection();
	});
	function debugstr(text){
		$(".ywkcdmtip").text(text).animate({opacity: "1"},10).animate({top:"-=200px", opacity: "0"},1500).animate({top:"50%", opacity: "0"},10);
		var spanwth=$(".ywkcdmtip").width();
		$(".ywkcdmtip").css({marginLeft:-spanwth/2})
	}
});

//若无十足把握，切勿修改以上代码，容易出错