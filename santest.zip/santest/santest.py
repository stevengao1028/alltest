#-*- coding:utf-8 -*-
from flask import Flask, render_template, request, redirect, url_for, make_response,flash
from get_remote_byssh import *
import os,time,sqlite3,json
# from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
# basedir= os.path.abspath(os.path.dirname(__file__))
# print basedir
db="C:\Users\gao\PycharmProjects\santest\data.sqlite"
# app.config['SQLALCHEMY_DATABASE_URI'] ='sqlite:///'+ os.path.join(basedir,'data.sqlite')
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
# app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] =True
# db = SQLAlchemy(app)
# app.config.from_pyfile('config')

# class stats(db.Model):
#     """定义数据模型"""
#     __tablename__ = 'stats'
#     time = db.Column(db.String(50))
#     item = db.Column(db.String(50))
#     info = db.Column(db.String(50))
#
#     # def __init__(self, statusitem, statustime,statu):
#     #     self.time = statustime
#     #     self.item = statusitem
#     #     self.info = statu


#数据库
# @app.route('/statussql/')
# def statussql():
    # try:
    # db.create_all()
    # while 1 :
    # cpuinfo = get("cpu")
    # meminfo = get("mem")
    # diskinfo =get("disk")
    # print cpuinfo,meminfo,diskinfo
    # nowtime=str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
    # print nowtime
    # cpustatu = serverstat(statustime=nowtime,statusitem='cpu',statu=cpuinfo)
    # memstatu = serverstat(statustime=nowtime,statusitem='mem',statu=meminfo)
    # diskstatu = serverstat(statustime=nowtime,statusitem="disk",statu=diskinfo)
    # db.session.add(cpustatu)
    # db.session.add(memstatu)
    # db.session.add(diskstatu)
    # db.session.commit()
    # except:
    #     pass
    # finally:

    # status = stats.query.all()
    # print status
    # return  "yes"
@app.route('/getstats/',methods=['GET'])
def getstats():
    if request.method == 'GET':
        # db="C:\Users\gao\PycharmProjects\santest\data.sqlite"
        # print db
        conn = sqlite3.connect(db)
        c = conn.cursor()
        # print "ok"
        cursor=c.execute("select * from  stats order by time desc limit 5 ")
        ret =[]
        for row in cursor:
            tmp ={'time':row[0],'cpu':row[1],'mem':row[2],'disk':row[3]}
            # print tmp
            ret.append(tmp)
        conn.close()
        result =json.dumps(ret)
        # print result
        return result
    pass


@app.route('/')
def hello_world():
    return render_template('pie.html')

@app.route('/status/')
def status():
    return render_template('status.html')


@app.route('/index/')
def index():
    # hostname=get("hostname")
    # # ip=get("ip")
    # cpu=get("cpu")
    # disk=get("disk")
    # mem=get("mem")
    # print cpu,disk,mem
    return render_template('index1.html')
    #return render_template('index1.html', disk=disk,cpu=cpu,mem=mem,network=ip)


@app.route('/getcpu/', methods=['GET'])
def getcpu():
    if request.method=="GET":
       while 1:
           disk = get("disk")
           print disk
           return disk





if __name__ == '__main__':
    app.run(debug=True)
