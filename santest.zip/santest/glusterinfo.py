#-*- coding:utf-8 -*-
import os,time,socket


info =os.popen('gluster volume info')
for line in info.readlines():
    print line

