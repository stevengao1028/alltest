#!/usr/bin/python
#-*- coding:utf-8 -*-
import paramiko

def get(info):
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect("192.168.220.217", 22, "root", "standard")
        stdin, stdout, stderr = ssh.exec_command("python /tmp/info.py "+info)
        # print stdout.read()
        result = stdout.read()
        # print stdout.readlines()
        ssh.close()
        return result
