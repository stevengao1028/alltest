#-*- coding:utf-8 -*-
from get_remote_byssh import  *
import os,time,socket
import sqlite3
basedir= os.path.abspath(os.path.dirname(__file__))
# print basedir
conn = sqlite3.connect('data.sqlite')
c = conn.cursor()

def create():
    c.execute('''CREATE TABLE stats
           (
           DATE       CHAR(50),
           TIME       CHAR(50),
           CPU        CHAR(50),
           TotalMem   CHAR(50),
           UsageMEM   CHAR(50),
           Disk       CHAR(50),
           NET        CHAR(50));''')
    print "Table created successfully";
    conn.commit()
    # conn.close()

def get_hostname():
    hostname = socket.gethostname()
    return hostname


# def cpu_rate():
#     import time
#     def cpu_r():
#         f = open("/proc/stat", "r")
#         for f_line in f:
#             break
#         f.close()
#         f_line = f_line.split(" ")
#         f_line_a = []
#         for i in f_line:
#             if i.isdigit():
#                 i = int(i)
#                 f_line_a.append(i)
#         total = sum(f_line_a)
#         idle = f_line_a[3]
#         return total, idle
#
#     total_a, idle_a = cpu_r()
#     time.sleep(2)
#     total_b, idle_b = cpu_r()
#
#     sys_idle = idle_b - idle_a
#     sys_total = total_b - total_a
#     sys_us = sys_total - sys_idle
#
#     cpu_a = (float(sys_us) / sys_total) * 100
#     print cpu_a
#     return cpu_a


#!/usr/bin/python
#filename:meminfo.py


# def meminfo():
#     '''return the info of /proc/meminfo
#     as a dictionary
#     '''
#     meminfo = {}
#
#     with open('/proc/meminfo') as f:
#         for line in f:
#             meminfo[line.split(':')[0]]=line.split(':')[1].strip()
#     return meminfo
#
# if __name__ == '__main__':
#     meminfo = meminfo()
#
#     print("Total memory:{0}".format(meminfo['MemTotal']))
#     print("Free memory:{0}".format(meminfo['MemFree']))



def insert():
    # c = conn.cursor()
    nowtime = str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
    cpuinfo = get("cpu")
    meminfo = get("mem")
    diskinfo =get("disk")
    statinfo=(nowtime,cpuinfo,meminfo,diskinfo)
    ins = "insert into stats values(?,?,?,?);"
    c.execute(ins, statinfo)
    conn.commit()
    # conn.close()
    print "ok",nowtime,cpuinfo,meminfo,diskinfo


# create()
#insert()
try:
    while 1:
        insert()
        time.sleep(5)
except KeyboardInterrupt:
    conn.close()
    pass

