#-*- coding:utf-8 -*-
import re
import get_status_py
#post code
#email address
# pattern = re.compile('13[0-9]{9}')
# while 1:
#     try:
#         a = raw_input("please input post code:")
#         if  pattern.search(a):
#             print "It`s post code" +a
#         else:
#             print "please input post code again"
#     except:
#         break

class test:
     date = "2017-08-23"
     def __init__(self):
          self.cpu = 2
          self.mem = 8
     def get(self,info):
          if info == "cpu":
               return self.cpu
          elif info == "mem":
               return self.mem

if __name__ == '__main__':
     servera = test()
     print servera.date
     print servera.cpu
     result =servera.get("mem")
     print result


